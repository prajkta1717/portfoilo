---
layout: list
title: Hyde
slug: hyde
menu: true
order: 2
description: >
  Hyde is a brazen two-column Jekyll theme that pairs a prominent sidebar with uncomplicated content.
  It’s based on Poole, the Jekyll butler.
  Open `_featured_tags/hyde.md` to edit this text.
accent_color: rgb(38,139,210)
accent_image:
  background: rgb(32,32,32)
  overlay:    false
---
