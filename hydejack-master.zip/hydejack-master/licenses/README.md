# Licenses

## Open Source
* [Apache-2.0](./Apache-2.0.md)
* [GPL-3.0](./GPL-3.0.md)
* [MIT](./MIT.md)
* [W3C](./W3C.md)

## Custom
* [PRO](./PRO.md)
